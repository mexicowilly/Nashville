#include "main_window.hpp"
#include "side_panel.hpp"
#include "song_tab.hpp"
#include "../database.hpp"
#include "../model/playlist.hpp"
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QTabWidget>
#include <QToolButton>
#include <QLabel>
#include <QListWidget>
#include <QPalette>
#include <QInputDialog>
#include <QMessageBox>

namespace nashville::view
{

main_window::main_window(database& db, QWidget* parent)
    : QWidget(parent)
    , db_(db)
{
    // Force a white-paper background here too, matching the rest of
    // the app's print-look palette policy.
    QPalette pal = palette();
    pal.setColor(QPalette::Window, Qt::white);
    pal.setColor(QPalette::Base,   Qt::white);
    pal.setColor(QPalette::Text,   Qt::black);
    pal.setColor(QPalette::WindowText, Qt::black);
    setPalette(pal);
    setAutoFillBackground(true);

    // --- Layout ---
    // Outer: [side_panel] [main column]
    // Main column: [top bar with hamburger] [tab widget]
    auto* outer = new QHBoxLayout(this);
    outer->setContentsMargins(0, 0, 0, 0);
    outer->setSpacing(0);

    panel_ = new side_panel(this);
    outer->addWidget(panel_);

    auto* main_col = new QVBoxLayout;
    main_col->setContentsMargins(0, 0, 0, 0);
    main_col->setSpacing(0);
    outer->addLayout(main_col, /*stretch=*/1);

    // Top bar with the hamburger.  A thin row holding just the
    // toggle button, left-aligned.  We pad it slightly so the button
    // doesn't kiss the window edge.  Using a QHBoxLayout for the bar
    // even though it has one widget so a future right-side affordance
    // (e.g. an account menu, a sync indicator) can be added without
    // restructuring.
    auto* top_bar = new QHBoxLayout;
    top_bar->setContentsMargins(4, 4, 4, 0);
    top_bar->setSpacing(0);

    hamburger_ = new QToolButton(this);
    // The Unicode triple-bar U+2630 is the universal hamburger glyph;
    // using it avoids shipping an icon file.  Size up the font a touch
    // so the symbol is easy to hit.
    hamburger_->setText(QString::fromUtf8("\xE2\x98\xB0"));
    QFont hf = hamburger_->font();
    hf.setPointSize(hf.pointSize() + 4);
    hamburger_->setFont(hf);
    hamburger_->setToolTip(tr("Show songs and playlists"));
    hamburger_->setAutoRaise(true);   // flat until hovered — keeps
                                      // the toolbar visually quiet
                                      // alongside the chart
    connect(hamburger_, &QToolButton::clicked,
            panel_, &side_panel::toggle_animated);
    top_bar->addWidget(hamburger_);
    top_bar->addStretch(1);

    main_col->addLayout(top_bar);

    // The tab widget.  Tabs are closable; close requests come back to
    // close_tab_at where we flush-save and drop the tab.  Tabs are
    // movable so users can reorder their workspace.
    tabs_ = new QTabWidget(this);
    tabs_->setTabsClosable(true);
    tabs_->setMovable(true);
    tabs_->setDocumentMode(true);   // less chrome, more chart-like
    connect(tabs_, &QTabWidget::tabCloseRequested,
            this, &main_window::close_tab_at);
    connect(tabs_, &QTabWidget::currentChanged,
        [this](int /*idx*/) {
            emit current_tab_changed(current_tab());
        });
    main_col->addWidget(tabs_, /*stretch=*/1);

    // Wire side-panel signals.  Songs open into tabs.  Playlist
    // double-click is currently a no-op (a slot is connected for
    // future use, just doesn't do anything yet).
    connect(panel_, &side_panel::song_double_clicked,
        [this](const QString& name) {
            open_song(name.toStdString());
        });
    connect(panel_, &side_panel::playlist_double_clicked,
        [](const QString& /*name*/) {
            // No-op for now.  Future: open all playlist songs as tabs.
        });

    // Add / delete from the side panel.  We forward to the same
    // confirm_delete_* / prompt_new_* methods the top-level menus
    // call so behavior is identical regardless of how the user got
    // here.  Keeping the prompts here (in main_window, not in
    // side_panel) means side_panel stays database-ignorant and
    // testable in isolation.
    connect(panel_, &side_panel::add_song_requested,
            this, &main_window::prompt_new_song);
    connect(panel_, &side_panel::add_playlist_requested,
            this, &main_window::prompt_new_playlist);
    connect(panel_, &side_panel::delete_song_requested,
        [this](const QString& name) {
            confirm_delete_song(name.toStdString());
        });
    connect(panel_, &side_panel::delete_playlist_requested,
        [this](const QString& name) {
            confirm_delete_playlist(name.toStdString());
        });

    // Populate lists on construction.  The database is already open
    // at this point (app constructs it before us), so these queries
    // return the current names.
    refresh_lists();
}

void main_window::refresh_lists()
{
    try
    {
        panel_->set_song_names(db_.select_song_names());
        panel_->set_playlist_names(db_.select_playlist_names());
    }
    catch (const std::exception&)
    {
        // If the DB is broken we don't want to crash the UI.  An
        // empty list is the right fallback; the user will notice
        // their songs are missing and we'll surface a real error
        // through the status bar later.
    }
}

void main_window::open_song(const std::string& name)
{
    // Already open?  Focus the existing tab.  Tabs are uniquely
    // keyed by song name because the database enforces unique song
    // names — opening "Yesterday" twice would either mean two tabs
    // editing the same row (bad) or just confusing the user.
    const int existing = find_tab_by_name(name);
    if (existing >= 0)
    {
        tabs_->setCurrentIndex(existing);
        return;
    }

    // Load from the database.  select_song throws if the name isn't
    // found; that shouldn't happen here because the only path to
    // this method is a double-click on a name we just listed, but
    // be defensive.
    std::unique_ptr<model::song> song;
    try
    {
        song = std::make_unique<model::song>(db_.select_song(name));
    }
    catch (const std::exception&)
    {
        return;
    }

    auto* tab = new song_tab(std::move(song), db_, this);
    const int idx = tabs_->addTab(tab, tab->tab_name());
    tabs_->setCurrentIndex(idx);
}

void main_window::close_tab_at(int index)
{
    if (index < 0 || index >= tabs_->count())
        return;
    QWidget* w = tabs_->widget(index);
    auto* tab = qobject_cast<song_tab*>(w);
    if (tab)
        tab->flush_save();   // belt and suspenders — destructor flushes too,
                              // but flushing here means the side-panel
                              // refresh below sees the post-save state
    tabs_->removeTab(index);
    if (tab)
        tab->deleteLater();
    refresh_lists();
    emit current_tab_changed(current_tab());
}

void main_window::flush_all_tabs()
{
    for (int i = 0; i < tabs_->count(); ++i)
    {
        if (auto* tab = qobject_cast<song_tab*>(tabs_->widget(i)))
            tab->flush_save();
    }
}

int main_window::find_tab_by_name(const std::string& name) const
{
    for (int i = 0; i < tabs_->count(); ++i)
    {
        if (auto* tab = qobject_cast<song_tab*>(tabs_->widget(i)))
        {
            if (tab->song_name() == name)
                return i;
        }
    }
    return -1;
}

song_tab* main_window::current_tab() const
{
    if (tabs_->count() == 0)
        return nullptr;
    return qobject_cast<song_tab*>(tabs_->currentWidget());
}

std::string main_window::selected_song_name() const
{
    return panel_->selected_song_name().toStdString();
}

std::string main_window::selected_playlist_name() const
{
    return panel_->selected_playlist_name().toStdString();
}

// ---------------------------------------------------------------------------
// Name-validation helper
// ---------------------------------------------------------------------------
// Standardize the "is this a usable new name" check so the songs and
// playlists paths can't drift apart.  Empty names are rejected — the
// database technically allows empty strings but the UI treats them as
// "user cancelled," and an unnamed item is unfindable in the lists.
// We also reject names that already exist in the relevant collection;
// the database would raise on collision but a friendly dialog now
// beats a stack-trace later.  Caller passes the existing names; we
// don't query the database here because the caller usually has them
// already from refresh_lists.
static bool is_usable_new_name(const QString& candidate,
                               const std::vector<std::string>& existing,
                               QWidget* parent,
                               const QString& kind)  // "song" / "playlist"
{
    const QString trimmed = candidate.trimmed();
    if (trimmed.isEmpty())
        return false;  // treat as cancel; caller doesn't show a dialog
    for (const auto& e : existing)
    {
        if (QString::fromStdString(e) == trimmed)
        {
            QMessageBox::warning(parent,
                QObject::tr("Name already in use"),
                QObject::tr("A %1 named \"%2\" already exists. "
                            "Please choose a different name.")
                    .arg(kind, trimmed));
            return false;
        }
    }
    return true;
}

void main_window::prompt_new_song()
{
    // QInputDialog::getText is the standard "ask the user for a
    // line of text" pattern.  Returning ok=false means the user
    // cancelled — silent no-op.  Returning ok=true with empty text
    // is also a no-op (treated as cancel by is_usable_new_name).
    bool ok = false;
    const QString name = QInputDialog::getText(this,
        tr("New song"),
        tr("Song name:"),
        QLineEdit::Normal,
        QString(),
        &ok);
    if (!ok) return;
    const QString trimmed = name.trimmed();
    if (!is_usable_new_name(trimmed, db_.select_song_names(), this, tr("song")))
        return;

    // Create an empty in-memory song with the chosen name and
    // persist it.  Then refresh the lists and open the new song in
    // a tab so the user can immediately start editing.  The empty
    // song carries no bars and no annotations; the editor handles
    // that state (you can still set the title/key/time-sig/tempo
    // and start adding bars).
    try
    {
        model::song s(trimmed.toStdString());
        db_.insert_song(s);
    }
    catch (const std::exception& e)
    {
        QMessageBox::critical(this, tr("Could not create song"),
            QString::fromUtf8(e.what()));
        return;
    }
    refresh_lists();
    open_song(trimmed.toStdString());
}

void main_window::prompt_new_playlist()
{
    bool ok = false;
    const QString name = QInputDialog::getText(this,
        tr("New playlist"),
        tr("Playlist name:"),
        QLineEdit::Normal,
        QString(),
        &ok);
    if (!ok) return;
    const QString trimmed = name.trimmed();
    if (!is_usable_new_name(trimmed, db_.select_playlist_names(), this, tr("playlist")))
        return;

    try
    {
        model::playlist pl(trimmed.toStdString());
        db_.insert_playlist(pl);
    }
    catch (const std::exception& e)
    {
        QMessageBox::critical(this, tr("Could not create playlist"),
            QString::fromUtf8(e.what()));
        return;
    }
    refresh_lists();
}

void main_window::confirm_delete_song(const std::string& name)
{
    if (name.empty()) return;

    const QString qname = QString::fromStdString(name);
    const auto answer = QMessageBox::question(this,
        tr("Delete song"),
        tr("Delete the song \"%1\"?\n\n"
           "This cannot be undone.").arg(qname),
        QMessageBox::Yes | QMessageBox::No,
        QMessageBox::No);   // default to No — destructive operation,
                            // so the safer answer should win an
                            // accidental Enter key
    if (answer != QMessageBox::Yes)
        return;

    // If the song has an open tab, close it WITHOUT flushing.  If we
    // flushed, the auto-save's insert_song would resurrect the row
    // we're about to delete — a near-impossible-to-debug race
    // between the UI and the DB.  Cancel the tab's pending save by
    // stopping its timer (via flush + delete, where we deliberately
    // don't call flush — see song_tab::flush_save which we DO want
    // to skip here).  Cleanest approach: locate the tab, remove it
    // from the tab widget (which triggers song_tab destruction,
    // whose destructor calls flush_save — undesired) — so instead
    // we close the tab through a custom path that doesn't flush.
    //
    // We do this by manually stopping the save timer (via a public
    // accessor on song_tab) and then closing the tab.  But song_tab
    // doesn't expose its timer; the simplest robust answer is to
    // just delete the row from the DB FIRST, then close the tab
    // (its flush will fail or write a row that doesn't matter
    // because we've already deleted it).
    //
    // Even simpler and more correct: delete the row, close the tab,
    // and accept that the close's flush may briefly re-insert the
    // row.  Then explicitly re-delete.  Belt and suspenders.
    const int existing = find_tab_by_name(name);
    try
    {
        db_.remove_song(name);
    }
    catch (const std::exception& e)
    {
        QMessageBox::critical(this, tr("Could not delete song"),
            QString::fromUtf8(e.what()));
        return;
    }
    if (existing >= 0)
    {
        QWidget* w = tabs_->widget(existing);
        tabs_->removeTab(existing);
        if (auto* tab = qobject_cast<song_tab*>(w))
        {
            // song_tab's destructor calls flush_save, which would
            // re-insert the row we just deleted.  Re-delete after
            // the destructor runs.  deleteLater queues destruction
            // to the next event-loop turn so we have time to
            // schedule the cleanup re-delete on the same turn.
            tab->deleteLater();
        }
        // Cleanup re-delete: posted to the event loop so it runs
        // AFTER the song_tab destructor's auto-save.  Catches the
        // (very narrow but possible) race where the flush re-
        // inserted the row.  The lambda holds the name by value,
        // so no dangling-reference risk.
        QMetaObject::invokeMethod(this, [this, name]() {
            try { db_.remove_song(name); }
            catch (const std::exception&) { /* already gone, fine */ }
            refresh_lists();
            emit current_tab_changed(current_tab());
        }, Qt::QueuedConnection);
    }
    refresh_lists();
}

void main_window::confirm_delete_playlist(const std::string& name)
{
    if (name.empty()) return;

    const QString qname = QString::fromStdString(name);
    const auto answer = QMessageBox::question(this,
        tr("Delete playlist"),
        tr("Delete the playlist \"%1\"?\n\n"
           "This cannot be undone.").arg(qname),
        QMessageBox::Yes | QMessageBox::No,
        QMessageBox::No);
    if (answer != QMessageBox::Yes)
        return;

    try
    {
        db_.remove_playlist(name);
    }
    catch (const std::exception& e)
    {
        QMessageBox::critical(this, tr("Could not delete playlist"),
            QString::fromUtf8(e.what()));
        return;
    }
    refresh_lists();
}

} // namespace nashville::view
