#include "side_panel.hpp"
#include <QListWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLabel>
#include <QPropertyAnimation>
#include <QEasingCurve>
#include <QPalette>
#include <QToolButton>
#include <QMenu>
#include <QAction>

namespace nashville::view
{

// Build a "+" button: a small flat tool button with a black ⊕-ish
// glyph on a white background.  We use Unicode U+2295 CIRCLED PLUS
// (⊕) — visually distinct from a plain "+" and renders consistently
// across platform fonts because it's a single character rather than
// a composed glyph.  Flat / autoRaise so the section header reads as
// quiet typography with one small affordance, not a chunky toolbar.
// Tooltip describes the action; same idiom is reused for the
// playlists button.
static QToolButton* make_add_button(QWidget* parent, const QString& tip)
{
    auto* b = new QToolButton(parent);
    b->setText(QString::fromUtf8("\xE2\x8A\x95"));   // ⊕
    QFont f = b->font();
    f.setPointSize(f.pointSize() + 2);
    b->setFont(f);
    b->setAutoRaise(true);
    b->setToolTip(tip);
    // Tighten the button's bounding box — the default QToolButton
    // sizing is too generous for a single-glyph button next to a
    // label.  Fixed size matches the line-height of the bold label
    // so the row looks like a unit.
    b->setFixedSize(20, 20);
    return b;
}

side_panel::side_panel(QWidget* parent)
    : QWidget(parent)
{
    auto* vl = new QVBoxLayout(this);
    vl->setContentsMargins(8, 8, 8, 8);
    vl->setSpacing(4);

    QFont section_font;     // applied to both section labels below

    // --- Songs section ---
    // Header row: [label] [stretch] [+]  — left-aligned label, right-
    // aligned add button so the two affordances aren't fighting for
    // attention.  The label and button together act as the section
    // anchor; the button doesn't need its own row because the
    // section is meant to read as a unit.
    auto* songs_header = new QHBoxLayout;
    songs_header->setContentsMargins(0, 0, 0, 0);
    songs_header->setSpacing(4);

    auto* songs_label = new QLabel(tr("Songs"), this);
    section_font = songs_label->font();
    section_font.setBold(true);
    songs_label->setFont(section_font);
    songs_header->addWidget(songs_label);
    songs_header->addStretch(1);

    auto* add_song_btn = make_add_button(this, tr("New song..."));
    connect(add_song_btn, &QToolButton::clicked,
            this, &side_panel::add_song_requested);
    songs_header->addWidget(add_song_btn);

    vl->addLayout(songs_header);

    songs_ = new QListWidget(this);
    songs_->setAlternatingRowColors(false);  // alternating rows look
                                             // weird against the white
                                             // print palette we force
                                             // on the rest of the app
    // CustomContextMenu so we can build a per-item right-click menu
    // ourselves (the default DefaultContextMenu would give a stock
    // QListWidget menu we don't want).
    songs_->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(songs_, &QListWidget::customContextMenuRequested,
        [this](const QPoint& pos) {
            auto* item = songs_->itemAt(pos);
            if (!item) return;
            // Select the right-clicked item so the visual cue
            // matches the context.  Without this the menu can pop
            // up over a row that doesn't appear selected, which is
            // disorienting.
            songs_->setCurrentItem(item);
            const QString name = item->text();
            QMenu menu(this);
            QAction* del = menu.addAction(tr("Delete \"%1\"...").arg(name));
            connect(del, &QAction::triggered,
                [this, name]() { emit delete_song_requested(name); });
            menu.exec(songs_->mapToGlobal(pos));
        });
    vl->addWidget(songs_, /*stretch=*/2);     // songs gets more space
                                              // than playlists by
                                              // default — most users
                                              // have far more songs
                                              // than playlists

    // --- Playlists section ---
    auto* playlists_header = new QHBoxLayout;
    playlists_header->setContentsMargins(0, 0, 0, 0);
    playlists_header->setSpacing(4);

    auto* playlists_label = new QLabel(tr("Playlists"), this);
    playlists_label->setFont(section_font);
    playlists_header->addWidget(playlists_label);
    playlists_header->addStretch(1);

    auto* add_playlist_btn = make_add_button(this, tr("New playlist..."));
    connect(add_playlist_btn, &QToolButton::clicked,
            this, &side_panel::add_playlist_requested);
    playlists_header->addWidget(add_playlist_btn);

    vl->addLayout(playlists_header);

    playlists_ = new QListWidget(this);
    playlists_->setAlternatingRowColors(false);
    playlists_->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(playlists_, &QListWidget::customContextMenuRequested,
        [this](const QPoint& pos) {
            auto* item = playlists_->itemAt(pos);
            if (!item) return;
            playlists_->setCurrentItem(item);
            const QString name = item->text();
            QMenu menu(this);
            QAction* del = menu.addAction(tr("Delete \"%1\"...").arg(name));
            connect(del, &QAction::triggered,
                [this, name]() { emit delete_playlist_requested(name); });
            menu.exec(playlists_->mapToGlobal(pos));
        });
    vl->addWidget(playlists_, /*stretch=*/1);

    // Double-click handlers.  QListWidget emits itemDoubleClicked
    // (not itemActivated) on a literal double-click — itemActivated
    // also fires on Enter, which would let a list-focused user trigger
    // an open with the keyboard.  We want the keyboard path too, so
    // wire both.  Both ultimately dispatch through the same signal
    // since the host can't tell the difference and shouldn't care.
    connect(songs_, &QListWidget::itemDoubleClicked,
        [this](QListWidgetItem* item) {
            if (item) emit song_double_clicked(item->text());
        });
    connect(songs_, &QListWidget::itemActivated,
        [this](QListWidgetItem* item) {
            if (item) emit song_double_clicked(item->text());
        });
    connect(playlists_, &QListWidget::itemDoubleClicked,
        [this](QListWidgetItem* item) {
            if (item) emit playlist_double_clicked(item->text());
        });
    connect(playlists_, &QListWidget::itemActivated,
        [this](QListWidgetItem* item) {
            if (item) emit playlist_double_clicked(item->text());
        });

    // Animation setup.  We animate maximumWidth so the parent layout
    // (a QHBoxLayout in main_window) resizes the side panel as we
    // change it.  minimumWidth follows the same value so the panel
    // doesn't have a fixed width that fights the animation.  Easing
    // curve OutCubic gives a snappy start and a soft stop, which
    // reads as "responsive" without being jarring — same curve used
    // by most slide-out drawers in mobile UIs.
    setMinimumWidth(0);
    setMaximumWidth(0);
    anim_ = new QPropertyAnimation(this, "maximumWidth", this);
    anim_->setDuration(200);
    anim_->setEasingCurve(QEasingCurve::OutCubic);

    // Force a white-on-light palette so the panel matches the chart's
    // print look regardless of system dark mode.  Same idiom used
    // elsewhere in the app — see app.cpp's force_white_background
    // helper for the rationale.
    QPalette pal = palette();
    pal.setColor(QPalette::Window, Qt::white);
    pal.setColor(QPalette::Base,   Qt::white);
    pal.setColor(QPalette::Text,   Qt::black);
    pal.setColor(QPalette::WindowText, Qt::black);
    setPalette(pal);
    setAutoFillBackground(true);
}

void side_panel::set_song_names(const std::vector<std::string>& names)
{
    rebuild_list(songs_, names);
}

void side_panel::set_playlist_names(const std::vector<std::string>& names)
{
    rebuild_list(playlists_, names);
}

// Clear-and-refill rather than diff: the names list is small (a few
// hundred at most for a working musician's library), so the cost is
// nil and the code is simpler.  Preserves selection by name when
// possible so a user-driven refresh (e.g. after closing a tab)
// doesn't lose the user's cursor position.
void side_panel::rebuild_list(QListWidget* list,
                              const std::vector<std::string>& names)
{
    const QString prev_selected = list->currentItem()
        ? list->currentItem()->text()
        : QString();

    list->clear();
    int select_row = -1;
    for (int i = 0; i < int(names.size()); ++i)
    {
        const QString s = QString::fromStdString(names[i]);
        list->addItem(s);
        if (!prev_selected.isEmpty() && s == prev_selected)
            select_row = i;
    }
    if (select_row >= 0)
        list->setCurrentRow(select_row);
}

void side_panel::show_animated()
{
    if (expanded_) return;
    expanded_ = true;
    // Stop any in-flight reverse animation before reversing direction
    // — without this the animation would jump from the current width
    // back to 0 and then re-animate to expanded.  stop() leaves the
    // property at its current value, which is the right starting
    // point for the new direction.
    anim_->stop();
    anim_->setStartValue(maximumWidth());
    anim_->setEndValue(k_expanded_width);
    anim_->start();
}

void side_panel::hide_animated()
{
    if (!expanded_) return;
    expanded_ = false;
    anim_->stop();
    anim_->setStartValue(maximumWidth());
    anim_->setEndValue(0);
    anim_->start();
}

void side_panel::toggle_animated()
{
    if (expanded_) hide_animated();
    else           show_animated();
}

QString side_panel::selected_song_name() const
{
    auto* item = songs_->currentItem();
    return item ? item->text() : QString();
}

QString side_panel::selected_playlist_name() const
{
    auto* item = playlists_->currentItem();
    return item ? item->text() : QString();
}

} // namespace nashville::view
