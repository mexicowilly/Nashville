#include "database.hpp"
#include <cassert>
#include <cstdlib>
#include <algorithm>
#include <map>
// Annotation binding/reading uses these directly; they're pulled in
// transitively via model/annotations.hpp, but listing them explicitly
// documents the dependency.
#include <QPointF>
#include <QRectF>
#include <QString>
#include <QByteArray>

using namespace std::string_literals;

namespace
{

const char* schema = R"(
PRAGMA encoding = 'UTF-8';
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS chord
(
    id INTEGER PRIMARY KEY,
    number INTEGER,
    mode INTEGER,
    flat_sharp BOOLEAN,
    bass_note INTEGER,
    bass_note_step BOOLEAN,
    extensions TEXT,
    is_staccato BOOLEAN,
    is_diamond BOOLEAN,
    duration INTEGER,
    is_tied BOOLEAN,
    is_pushed BOOLEAN
);

CREATE TABLE IF NOT EXISTS bar
(
    id INTEGER PRIMARY KEY,
    time_sig_id INTEGER,
    is_eol BOOLEAN,
    section TEXT,
    repeat INTEGER,
    voltas TEXT,
    FOREIGN KEY(time_sig_id) REFERENCES time_signature(id)
);

CREATE TABLE IF NOT EXISTS time_signature
(
    id INTEGER PRIMARY KEY,
    beat_type INTEGER CHECK(beat_type = 8 OR beat_type = 4 OR beat_type = 2),
    count INTEGER
);

CREATE TABLE IF NOT EXISTS bar_chords
(
    id INTEGER PRIMARY KEY,
    chord_id INTEGER,
    bar_id INTEGER,
    chord_index INTEGER,
    FOREIGN KEY(chord_id) REFERENCES chord(id) ON DELETE CASCADE,
    FOREIGN KEY(bar_id) REFERENCES bar(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS bar_id_index ON bar_chords(bar_id, chord_index);

CREATE TABLE IF NOT EXISTS song
(
    id INTEGER PRIMARY KEY,
    name TEXT UNIQUE,
    key TEXT,
    time_sig_id INTEGER,
    bars_per_line INTEGER,
    beats_per_minute INTEGER,
    beats_unit INTEGER,
    FOREIGN KEY(time_sig_id) REFERENCES time_signature(id)
);

CREATE TABLE IF NOT EXISTS song_bars
(
    id INTEGER PRIMARY KEY,
    bar_id INTEGER,
    song_id INTEGER,
    bar_index INTEGER,
    FOREIGN KEY(bar_id) REFERENCES bar(id) ON DELETE CASCADE,
    FOREIGN KEY(song_id) REFERENCES song(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS song_id_index ON song_bars(song_id, bar_index);

CREATE TABLE IF NOT EXISTS playlist
(
    id INTEGER PRIMARY KEY,
    name TEXT UNIQUE
);

CREATE TABLE IF NOT EXISTS playlist_songs
(
    id INTEGER PRIMARY KEY,
    song_id INTEGER,
    playlist_id INTEGER,
    song_index INTEGER,
    FOREIGN KEY(song_id) REFERENCES song(id) ON DELETE CASCADE,
    FOREIGN KEY(playlist_id) REFERENCES playlist(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS playlist_id_index ON playlist_songs(playlist_id, song_index);

CREATE TABLE IF NOT EXISTS text_box
(
    id INTEGER PRIMARY KEY,
    song_id INTEGER NOT NULL,
    x REAL NOT NULL,
    y REAL NOT NULL,
    w REAL NOT NULL,
    h REAL NOT NULL,
    text TEXT NOT NULL DEFAULT '',
    FOREIGN KEY(song_id) REFERENCES song(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS text_box_song_id_index ON text_box(song_id);

CREATE TABLE IF NOT EXISTS connector
(
    id INTEGER PRIMARY KEY,
    song_id INTEGER NOT NULL,
    -- Free-endpoint coordinates.  Used only when the corresponding
    -- start_text_box_id / end_text_box_id is NULL; otherwise these
    -- still get persisted (as the last-known resolved position) so
    -- a defensive read can fall back if the referenced text box has
    -- somehow gone missing, but they're authoritative only for
    -- free endpoints.
    x1 REAL NOT NULL,
    y1 REAL NOT NULL,
    x2 REAL NOT NULL,
    y2 REAL NOT NULL,
    arrow_start INTEGER NOT NULL DEFAULT 0,
    arrow_end   INTEGER NOT NULL DEFAULT 1,
    -- Anchor references.  NULL means "this endpoint is free; use the
    -- xN/yN coordinates."  NOT NULL means "glued to this text box's
    -- nth anchor (0..7)."  The FK uses ON DELETE SET NULL so that
    -- when a text box is removed at the database level (e.g. via
    -- some path that bypasses the in-memory annotations layer), the
    -- connector survives with the endpoint converted to free.
    start_text_box_id INTEGER,
    start_anchor_index INTEGER,
    end_text_box_id INTEGER,
    end_anchor_index INTEGER,
    FOREIGN KEY(song_id) REFERENCES song(id) ON DELETE CASCADE,
    FOREIGN KEY(start_text_box_id) REFERENCES text_box(id) ON DELETE SET NULL,
    FOREIGN KEY(end_text_box_id)   REFERENCES text_box(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS connector_song_id_index ON connector(song_id);
)";

const char* SELECT_CHORD_SQL = R"(
SELECT id FROM chord WHERE
    number = ?1 AND
    mode = ?2 AND
    flat_sharp IS ?3 AND
    bass_note IS ?4 AND
    bass_note_step IS ?5 AND
    extensions = ?6 AND
    is_staccato = ?7 AND
    is_diamond = ?8 AND
    duration IS ?9 AND
    is_tied = ?10 AND
    is_pushed = ?11;
)";

const char* SELECT_CHORDS_BY_BAR_SQL = R"(
SELECT chord_id FROM bar_chords WHERE bar_id = ?1 ORDER BY chord_index;
)";

const char* SELECT_CHORD_BY_ID_SQL = R"(
SELECT * FROM chord WHERE id = ?1;
)";

const char* INSERT_CHORD_SQL = R"(
INSERT INTO chord (number,
                   mode,
                   flat_sharp,
                   bass_note,
                   bass_note_step,
                   extensions,
                   is_staccato,
                   is_diamond,
                   duration,
                   is_tied,
                   is_pushed)
VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11)
RETURNING id;
)";

const char* SELECT_BAR_SQL = R"(
SELECT bar.is_eol,
       bar.section,
       time_signature.beat_type,
       time_signature.count,
       bar.repeat,
       bar.voltas
FROM bar
LEFT JOIN time_signature ON time_signature.id = bar.time_sig_id
WHERE bar.id = ?1;
)";

const char* INSERT_BAR_SQL = R"(
INSERT INTO bar (time_sig_id, is_eol, section, repeat, voltas)
VALUES (?1, ?2, ?3, ?4, ?5)
RETURNING id;
)";

const char* SELECT_TIME_SIGNATURE_SQL = R"(
SELECT * FROM time_signature WHERE (beat_type = ?1 AND count = ?2);
)";

const char* INSERT_TIME_SIGNATURE_SQL = R"(
INSERT INTO time_signature (beat_type, count)
VALUES (?1, ?2)
RETURNING id;
)";

const char* INSERT_BAR_CHORD_SQL = R"(
INSERT INTO bar_chords (chord_id, bar_id, chord_index)
VALUES (?1, ?2, ?3)
RETURNING id;
)";

const char* SELECT_SONGS_SQL = R"(
SELECT song.id,
       song.name,
       song.key,
       song.bars_per_line,
       song.beats_per_minute,
       song.beats_unit,
       time_signature.beat_type,
       time_signature.count
FROM song
LEFT JOIN time_signature ON time_signature.id = song.time_sig_id;
)";

const char* SELECT_SONG_SQL = R"(
SELECT song.id,
       song.key,
       song.bars_per_line,
       song.beats_per_minute,
       song.beats_unit,
       time_signature.beat_type,
       time_signature.count
FROM song
LEFT JOIN time_signature ON time_signature.id = song.time_sig_id
WHERE song.name = ?1;
)";

const char* SELECT_SONG_ID_SQL = R"(
SELECT id FROM song WHERE name = ?1;
)";

const char* SELECT_SONG_NAMES_SQL = R"(
SELECT name FROM song;
)";

const char* INSERT_SONG_SQL = R"(
INSERT INTO song (name,
                  key,
                  time_sig_id,
                  bars_per_line,
                  beats_per_minute,
                  beats_unit)
VALUES (?1, ?2, ?3, ?4, ?5, ?6)
RETURNING id;
)";

const char* SELECT_SONG_BARS_SQL = R"(
SELECT bar_id FROM song_bars WHERE song_id = ?1 ORDER BY bar_index;
)";

const char* INSERT_SONG_BAR_SQL = R"(
INSERT INTO song_bars (bar_id, song_id, bar_index)
VALUES (?1, ?2, ?3)
RETURNING id;
)";

const char* SELECT_PLAYLIST_NAMES_SQL = R"(
SELECT name FROM playlist;
)";

const char* INSERT_PLAYLIST_SQL = R"(
INSERT INTO playlist (name) VALUES (?1) RETURNING id;
)";

const char* SELECT_PLAYLIST_SONGS_SQL = R"(
SELECT song.name
FROM playlist_songs
JOIN song ON playlist_songs.song_id = song.id
WHERE playlist_songs.playlist_id = ?1
ORDER BY playlist_songs.song_index;
)";

const char* INSERT_PLAYLIST_SONG_SQL = R"(
INSERT INTO playlist_songs (song_id, playlist_id, song_index)
VALUES (?1, ?2, ?3);
)";

const char* SELECT_PLAYLIST_ID_SQL = R"(
SELECT id FROM playlist WHERE name = ?1;
)";

const char* SELECT_CHORD_NOT_IN_BAR_SQL = R"(
SELECT id FROM bar_chords WHERE (chord_id = ?1 AND bar_id != ?2);
)";

const char* REMOVE_CHORD_SQL = R"(
DELETE FROM chord WHERE id = ?1;
)";

const char* REMOVE_SONG_SQL = R"(
DELETE FROM song WHERE id = ?1;
)";

const char* REMOVE_BAR_SQL = R"(
DELETE FROM bar WHERE id = ?1;
)";

const char* REMOVE_PLAYLIST_SQL = R"(
DELETE FROM playlist WHERE name = ?1;
)";

// --- Annotation persistence -------------------------------------------------
// One row per text box / connector, FK'd to song with ON DELETE CASCADE.
// Coordinates are stored in song-local space (see annotation_layer for
// the convention) as REAL.  Connectors' arrow_* flags are stored as
// INTEGER booleans (0/1), same convention as bar.is_eol etc.

const char* INSERT_TEXT_BOX_SQL = R"(
INSERT INTO text_box (song_id, x, y, w, h, text)
VALUES (?1, ?2, ?3, ?4, ?5, ?6)
RETURNING id;
)";

const char* SELECT_SONG_TEXT_BOXES_SQL = R"(
SELECT id, x, y, w, h, text FROM text_box WHERE song_id = ?1 ORDER BY id;
)";

const char* INSERT_CONNECTOR_SQL = R"(
INSERT INTO connector
    (song_id, x1, y1, x2, y2, arrow_start, arrow_end,
     start_text_box_id, start_anchor_index,
     end_text_box_id,   end_anchor_index)
VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11)
RETURNING id;
)";

const char* SELECT_SONG_CONNECTORS_SQL = R"(
SELECT id, x1, y1, x2, y2, arrow_start, arrow_end,
       start_text_box_id, start_anchor_index,
       end_text_box_id,   end_anchor_index
FROM connector
WHERE song_id = ?1 ORDER BY id;
)";

}

namespace nashville
{

database::prepared::prepared(sqlite3* db, const char* const sql)
{
    auto rc = sqlite3_prepare_v2(db,
                                 sql,
                                 -1,
                                 &stmt_,
                                 NULL);
    if (rc != SQLITE_OK)
    {
        // THIS IS FATAL
        throw std::invalid_argument("Error preparing statement: '"s + sql + "': " + sqlite3_errstr(rc));
    }
}

database::prepared::~prepared()
{
    sqlite3_finalize(stmt_);
}

void database::prepared::reset()
{
    sqlite3_clear_bindings(stmt_);
    sqlite3_reset(stmt_);
}

database::transaction::transaction(database& db)
    : db_(db),
      is_committed_(false),
      is_active_(false)
{
    if (sqlite3_txn_state(db.db_, nullptr) == SQLITE_TXN_NONE)
    {
        char* err = nullptr;
        if (sqlite3_exec(db.db_, "BEGIN;", nullptr, nullptr, &err) != SQLITE_OK)
        {
            std::string msg = err ? err : "unknown error";
            sqlite3_free(err);
            throw std::runtime_error("Could not begin transaction: " + msg);
        }
        is_active_ = true;
        db.lgr()->debug("Created active transaction");
    }
    else
    {
        db.lgr()->debug("Created inactive transaction");
    }
}

database::transaction::~transaction()
{
    if (is_active_ && !is_committed_)
    {
        sqlite3_exec(db_.db_, "ROLLBACK;", nullptr, nullptr, nullptr);
        db_.lgr()->debug("Rolled back active transaction");
    }
}

void database::transaction::commit()
{
    if (is_active_)
    {
        for (auto& p : db_.prepared_statements_)
            p.second->reset();
        char* err = nullptr;
        if (sqlite3_exec(db_.db_, "COMMIT;", nullptr, nullptr, &err) != SQLITE_OK)
        {
            std::string msg = err ? err : "unknown error";
            sqlite3_free(err);
            throw std::runtime_error("Could not commit transaction: " + msg);
        }
        is_committed_ = true;
        db_.lgr()->debug("Committed active transaction");
    }
}

database::database()
    : database(":memory:")
{
}

database::database(const std::filesystem::path& file_name)
    : loggable("database")
{
    int rc = sqlite3_open_v2(file_name.c_str(),
                             &db_,
                             SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_EXRESCODE,
                             nullptr);
    if (rc != SQLITE_OK)
        throw std::runtime_error("Unable to open the database '"s + file_name.string() + "' " + sqlite3_errstr(rc));
    lgr()->debug("Opened the database '{}'", file_name.string());
    char* err;
    rc = sqlite3_exec(db_,
                      schema,
                      nullptr,
                      nullptr,
                      &err);
    if (rc != SQLITE_OK)
    {
        // THIS IS FATAL
        lgr()->critical("The database schema contains errors: {}", err);
        sqlite3_free(err);
        std::abort();
    }
    lgr()->debug("Successfully loaded the schema");
    try
    {
        struct stmt_def { statement key; const char* sql; };
        const stmt_def defs[] =
        {
            { statement::SELECT_CHORD,           SELECT_CHORD_SQL },
            { statement::SELECT_CHORD_BY_ID,     SELECT_CHORD_BY_ID_SQL },
            { statement::INSERT_CHORD,           INSERT_CHORD_SQL },
            { statement::SELECT_BAR,             SELECT_BAR_SQL },
            { statement::INSERT_BAR,             INSERT_BAR_SQL },
            { statement::SELECT_CHORDS_BY_BAR,   SELECT_CHORDS_BY_BAR_SQL },
            { statement::SELECT_TIME_SIGNATURE,  SELECT_TIME_SIGNATURE_SQL },
            { statement::INSERT_TIME_SIGNATURE,  INSERT_TIME_SIGNATURE_SQL },
            { statement::INSERT_BAR_CHORD,       INSERT_BAR_CHORD_SQL },
            { statement::SELECT_SONG_ID,         SELECT_SONG_ID_SQL },
            { statement::INSERT_SONG,            INSERT_SONG_SQL },
            { statement::SELECT_SONG_BARS,       SELECT_SONG_BARS_SQL },
            { statement::INSERT_SONG_BAR,        INSERT_SONG_BAR_SQL },
            { statement::INSERT_PLAYLIST,        INSERT_PLAYLIST_SQL },
            { statement::SELECT_PLAYLIST_SONGS,  SELECT_PLAYLIST_SONGS_SQL },
            { statement::INSERT_PLAYLIST_SONG,   INSERT_PLAYLIST_SONG_SQL },
            { statement::SELECT_SONG_NAMES,      SELECT_SONG_NAMES_SQL },
            { statement::SELECT_SONG,            SELECT_SONG_SQL },
            { statement::SELECT_PLAYLIST_NAMES,  SELECT_PLAYLIST_NAMES_SQL },
            { statement::SELECT_PLAYLIST_ID,     SELECT_PLAYLIST_ID_SQL },
            { statement::SELECT_CHORD_NOT_IN_BAR, SELECT_CHORD_NOT_IN_BAR_SQL },
            { statement::REMOVE_CHORD,           REMOVE_CHORD_SQL },
            { statement::REMOVE_BAR,             REMOVE_BAR_SQL },
            { statement::REMOVE_SONG,            REMOVE_SONG_SQL },
            { statement::REMOVE_PLAYLIST,        REMOVE_PLAYLIST_SQL },
            { statement::INSERT_TEXT_BOX,        INSERT_TEXT_BOX_SQL },
            { statement::SELECT_SONG_TEXT_BOXES, SELECT_SONG_TEXT_BOXES_SQL },
            { statement::INSERT_CONNECTOR,       INSERT_CONNECTOR_SQL },
            { statement::SELECT_SONG_CONNECTORS, SELECT_SONG_CONNECTORS_SQL },
        };

        for (const auto& d : defs)
            prepared_statements_.try_emplace(d.key, std::make_unique<prepared>(db_, d.sql));
    }
    catch (std::invalid_argument& e)
    {
        lgr()->critical(e.what());
        std::abort();
    }
    lgr()->debug("Successfully created the prepared statements");
}

database::~database()
{
    prepared_statements_.clear();
    sqlite3_close(db_);
}

std::filesystem::path database::file_name() const
{
    std::filesystem::path p;
    auto fn = sqlite3_db_filename(db_, "main");
    if (fn != nullptr || std::strlen(fn) != 0)
        p = fn;
    return p;
}

std::uint64_t database::insert_bar(const model::bar& b)
{
    assert(prepared_statements_.count(statement::INSERT_BAR) == 1);
    auto& ins_b = prepared_statements_[statement::INSERT_BAR];
    ins_b->reset();
    auto raw = ins_b->ptr();
    if (b.time_sig())
        sqlite3_bind_int64(raw, 1, time_signature_id(*b.time_sig()));
    sqlite3_bind_int(raw, 2, b.is_eol());
    if (b.section())
        sqlite3_bind_text(raw, 3, b.section()->c_str(), b.section()->length(), SQLITE_STATIC);
    sqlite3_bind_int(raw, 4, static_cast<int>(b.repeat()));
    if (!b.voltas().empty())
    {
        std::ostringstream out;
        for (auto v : b.voltas())
            out << v << ',';
        auto vtext = out.str();
        vtext.pop_back();
        sqlite3_bind_text(raw, 5, vtext.c_str(), vtext.length(), SQLITE_STATIC);
    }
    auto rc = sqlite3_step(raw);
    if (rc != SQLITE_ROW)
        throw std::runtime_error("Could not insert a bar: "s + sqlite3_errstr(rc));
    lgr()->debug("Inserted bar: {}", b.to_user_input());
    assert(sqlite3_column_count(raw) == 1);
    return sqlite3_column_int64(raw, 0);
}

std::uint64_t database::insert_bar_chord(std::uint64_t bar_id, std::uint64_t chord_id, unsigned index)
{
    assert(prepared_statements_.count(statement::INSERT_BAR_CHORD) == 1);
    auto& ins_bc = prepared_statements_[statement::INSERT_BAR_CHORD];
    ins_bc->reset();
    auto raw = ins_bc->ptr();
    sqlite3_bind_int(raw, 1, chord_id);
    sqlite3_bind_int(raw, 2, bar_id);
    sqlite3_bind_int(raw, 3, index);
    auto rc = sqlite3_step(raw);
    if (rc != SQLITE_ROW)
        throw std::runtime_error("Could not insert a bar chord: "s + sqlite3_errstr(rc));
    lgr()->debug("Inserted relation bar({}) with chord({}) position {}", bar_id, chord_id, index);
    assert(sqlite3_column_count(raw) == 1);
    return sqlite3_column_int64(raw, 0);
}

std::uint64_t database::insert_chord(const model::chord& c)
{
    assert(prepared_statements_.count(statement::SELECT_CHORD) == 1);
    auto& sel_c = prepared_statements_[statement::SELECT_CHORD];
    sel_c->reset();
    auto raw = sel_c->ptr();
    sqlite3_bind_int(raw, 1, c.number());
    sqlite3_bind_int(raw, 2, static_cast<int>(c.mode()));
    if (c.step())
        sqlite3_bind_int(raw, 3, static_cast<int>(*c.step()));
    if (c.bass_note())
        sqlite3_bind_int(raw, 4, *c.bass_note());
    if (c.bass_note_step())
        sqlite3_bind_int(raw, 5, static_cast<int>(*c.bass_note_step()));
    sqlite3_bind_text(raw, 6, c.extensions().c_str(), c.extensions().length(), SQLITE_STATIC);
    sqlite3_bind_int(raw, 7, c.is_staccato());
    sqlite3_bind_int(raw, 8, c.is_diamond());
    if (c.duration())
        sqlite3_bind_int(raw, 9, static_cast<int>(*c.duration()));
    sqlite3_bind_int(raw, 10, c.is_tied());
    sqlite3_bind_int(raw, 11, c.is_pushed());
    auto rc = sqlite3_step(raw);
    if (rc == SQLITE_ROW)
    {
        assert(sqlite3_column_count(raw) == 1);
        lgr()->debug("Found existing chord: {}", c.to_user_input());
        return sqlite3_column_int64(raw, 0);
    }
    assert(prepared_statements_.count(statement::INSERT_CHORD) == 1);
    auto& ins_c = prepared_statements_[statement::INSERT_CHORD];
    ins_c->reset();
    raw = ins_c->ptr();
    sqlite3_bind_int(raw, 1, c.number());
    sqlite3_bind_int(raw, 2, static_cast<int>(c.mode()));
    if (c.step())
        sqlite3_bind_int(raw, 3, static_cast<int>(*c.step()));
    if (c.bass_note())
        sqlite3_bind_int(raw, 4, *c.bass_note());
    if (c.bass_note_step())
        sqlite3_bind_int(raw, 5, static_cast<int>(*c.bass_note_step()));
    sqlite3_bind_text(raw, 6, c.extensions().c_str(), c.extensions().length(), SQLITE_STATIC);
    sqlite3_bind_int(raw, 7, c.is_staccato());
    sqlite3_bind_int(raw, 8, c.is_diamond());
    if (c.duration())
        sqlite3_bind_int(raw, 9, static_cast<int>(*c.duration()));
    sqlite3_bind_int(raw, 10, c.is_tied());
    sqlite3_bind_int(raw, 11, c.is_pushed());
    rc = sqlite3_step(raw);
    if (rc != SQLITE_ROW)
        throw std::runtime_error("Could not insert a chord: "s + sqlite3_errstr(rc));
    assert(sqlite3_column_count(raw) == 1);
    lgr()->debug("Inserted new chord: {}", c.to_user_input());
    return sqlite3_column_int64(raw, 0);
}

void database::insert_playlist(const model::playlist& pl)
{
    assert(prepared_statements_.count(statement::INSERT_PLAYLIST) == 1);
    assert(prepared_statements_.count(statement::SELECT_SONG_ID) == 1);
    assert(prepared_statements_.count(statement::INSERT_PLAYLIST_SONG) == 1);
    auto& ins_pl = prepared_statements_[statement::INSERT_PLAYLIST];
    auto& sel_sid = prepared_statements_[statement::SELECT_SONG_ID];
    auto& ins_ps = prepared_statements_[statement::INSERT_PLAYLIST_SONG];
    auto raw = ins_pl->ptr();
    int rc;
    bool inserted_new = true;
    transaction tx(*this);
    for (int i = 0; i < 2; i++)
    {
        ins_pl->reset();
        sqlite3_bind_text(raw, 1, pl.name().c_str(), pl.name().length(), SQLITE_STATIC);
        rc = sqlite3_step(raw);
        if (rc == SQLITE_CONSTRAINT_UNIQUE)
        {
            lgr()->debug("Replacing the playlist '{}'", pl.name());
            remove_playlist(pl.name());
            inserted_new = false;
        }
        else
        {
            break;
        }
    }
    if (rc != SQLITE_ROW)
        throw std::runtime_error("Could not insert playlist '"s + pl.name() + "':" + sqlite3_errstr(rc));
    auto pl_id = sqlite3_column_int64(raw, 0);
    for (int i = 0; i < pl.songs().size(); i++)
    {
        sel_sid->reset();
        const auto& n = pl.songs()[i];
        sqlite3_bind_text(sel_sid->ptr(), 1, n.c_str(), n.length(), SQLITE_STATIC);
        auto rc2 = sqlite3_step(sel_sid->ptr());
        if (rc2 == SQLITE_ROW)
        {
            ins_ps->reset();
            sqlite3_bind_int64(ins_ps->ptr(), 1, sqlite3_column_int64(sel_sid->ptr(), 0));
            sqlite3_bind_int64(ins_ps->ptr(), 2, pl_id);
            sqlite3_bind_int(ins_ps->ptr(), 3, i);
            rc2 = sqlite3_step(ins_ps->ptr());
            if (rc2 != SQLITE_DONE)
            {
                throw std::runtime_error("Could not insert a playlist song reference for playlist '"s +
                        pl.name() + "', song '" + n + "': " + sqlite3_errstr(rc2));
            }
        }
        else
        {
            throw std::runtime_error("Problem looking up a song named '"s + n + "':" + sqlite3_errstr(rc2));
        }
    }
    tx.commit();
    if (inserted_new)
        lgr()->debug("Inserted new playlist '{}'", pl.name());
}

void database::insert_song(const model::song& s)
{
    assert(prepared_statements_.count(statement::INSERT_SONG) == 1);
    auto& ins_s = prepared_statements_[statement::INSERT_SONG];
    auto raw = ins_s->ptr();
    int rc;
    bool inserted_new = true;
    transaction tx(*this);
    for (int i = 0; i < 2; i++)
    {
        ins_s->reset();
        sqlite3_bind_text(raw, 1, s.name().c_str(), s.name().length(), SQLITE_STATIC);
        sqlite3_bind_text(raw, 2, s.key().c_str(), s.key().length(), SQLITE_STATIC);
        sqlite3_bind_int64(raw, 3, time_signature_id(s.time_sig()));
        sqlite3_bind_int(raw, 4, s.bars_per_line());
        sqlite3_bind_int(raw, 5, std::get<0>(s.tempo()));
        sqlite3_bind_int(raw, 6, static_cast<int>(std::get<1>(s.tempo())));
        rc = sqlite3_step(raw);
        if (rc == SQLITE_CONSTRAINT_UNIQUE)
        {
            lgr()->debug("Replacing the song '{}'", s.name());
            remove_song(s.name());
            inserted_new = false;
        }
        else
        {
            break;
        }
    }
    if (rc != SQLITE_ROW)
        throw std::runtime_error("Unable to insert song '"s + s.name() + "': " + sqlite3_errstr(rc));
    assert(sqlite3_column_count(raw) == 1);
    auto song_id = sqlite3_column_int64(raw, 0);
    for (unsigned i = 0; i < s.bars().size(); i++)
    {
        auto& cur_bar = s.bars()[i];
        auto bar_id = insert_bar(cur_bar);
        for (unsigned j = 0; j < cur_bar.chords().size(); j++)
        {
            auto& cur_chord = cur_bar.chords()[j];
            auto chord_id = insert_chord(cur_chord);
            insert_bar_chord(bar_id, chord_id, j);
        }
        insert_song_bar(song_id, bar_id, i);
    }

    // --- Annotations ---
    // Same transaction, so a half-written annotation set won't leave a
    // partially-saved song.  Text boxes first then connectors —
    // connectors may have endpoints glued to text boxes, so we need
    // the text-box rows (and their RETURNING-assigned database ids)
    // before we can bind anchor references on the connector rows.
    // FK to song(id) is in place by this point (song_id came from the
    // INSERT above), so no FK violations are possible.
    //
    // text_box_id_map maps in-memory annotation ids to the database
    // rowids SQLite assigns on RETURNING.  These will usually differ
    // (the in-memory ids come from annotations::next_id_, which is
    // session-local; the database picks its own).  We only need the
    // map within this transaction, and connectors that reference
    // text-box ids read from this map.
    std::map<std::uint64_t, std::uint64_t> text_box_id_map;
    {
        auto& ins_tb = prepared_statements_[statement::INSERT_TEXT_BOX];
        for (const auto& tb : s.annotations().text_boxes())
        {
            ins_tb->reset();
            auto tb_raw = ins_tb->ptr();
            sqlite3_bind_int64 (tb_raw, 1, song_id);
            sqlite3_bind_double(tb_raw, 2, tb.rect.x());
            sqlite3_bind_double(tb_raw, 3, tb.rect.y());
            sqlite3_bind_double(tb_raw, 4, tb.rect.width());
            sqlite3_bind_double(tb_raw, 5, tb.rect.height());
            const QByteArray txt = tb.text.toUtf8();
            // SQLITE_TRANSIENT because the QByteArray dies at end of
            // scope; SQLite copies the bytes for us.
            sqlite3_bind_text  (tb_raw, 6, txt.constData(), txt.size(),
                                SQLITE_TRANSIENT);
            auto rc_tb = sqlite3_step(tb_raw);
            if (rc_tb != SQLITE_ROW)
                throw std::runtime_error(
                    "Could not insert text_box for song '"s + s.name()
                    + "': " + sqlite3_errstr(rc_tb));
            const std::uint64_t db_id = sqlite3_column_int64(tb_raw, 0);
            text_box_id_map[tb.id] = db_id;
        }
    }
    {
        auto& ins_c = prepared_statements_[statement::INSERT_CONNECTOR];
        for (const auto& c : s.annotations().connectors())
        {
            ins_c->reset();
            auto c_raw = ins_c->ptr();
            sqlite3_bind_int64 (c_raw, 1, song_id);

            // For each endpoint: write the resolved free-position
            // coordinates (so a defensive reader has a fallback) plus
            // the anchor reference if applicable.  Resolved positions
            // for glued endpoints come from the model's
            // resolver-of-record — which is the same lambda the view
            // installed on the model at startup, executed via
            // anchor_resolver.  But the database layer doesn't have
            // that lambda in scope; the natural place to compute the
            // fallback xN/yN for glued endpoints is the model itself.
            // We do it here inline because the geometry is trivial
            // (the 8 anchor positions on a known QRectF) — duplicating
            // it across two layers is cheaper than plumbing a callback.
            auto fallback_xy =
                [&](const model::connector_endpoint& ep) -> QPointF {
                    if (ep.k == model::connector_endpoint::kind::free)
                        return ep.free_pos;
                    const auto* tb = s.annotations().find_text_box(ep.text_box_id);
                    if (!tb || ep.anchor_index >= 8)
                        return QPointF(0, 0);
                    const QRectF& r = tb->rect;
                    const qreal cx = r.center().x(), cy = r.center().y();
                    switch (ep.anchor_index)
                    {
                    case 0: return { r.left(),  r.top()    };
                    case 1: return { cx,        r.top()    };
                    case 2: return { r.right(), r.top()    };
                    case 3: return { r.right(), cy         };
                    case 4: return { r.right(), r.bottom() };
                    case 5: return { cx,        r.bottom() };
                    case 6: return { r.left(),  r.bottom() };
                    case 7: return { r.left(),  cy         };
                    }
                    return QPointF(0, 0);
                };
            const QPointF s_xy = fallback_xy(c.start);
            const QPointF e_xy = fallback_xy(c.end);
            sqlite3_bind_double(c_raw, 2, s_xy.x());
            sqlite3_bind_double(c_raw, 3, s_xy.y());
            sqlite3_bind_double(c_raw, 4, e_xy.x());
            sqlite3_bind_double(c_raw, 5, e_xy.y());
            sqlite3_bind_int   (c_raw, 6, c.arrow_at_start ? 1 : 0);
            sqlite3_bind_int   (c_raw, 7, c.arrow_at_end   ? 1 : 0);

            // Anchor references: bind NULL for free endpoints, the
            // mapped DB id and anchor index for glued ones.  If a
            // glued endpoint references a text box we didn't insert
            // (defensive — every glued endpoint's box should be in
            // the same annotations set), we treat it as free.  Both
            // text_box_id and anchor_index columns go together — we
            // either bind both or NULL both.
            auto bind_anchor_ref =
                [&](int id_col, int idx_col,
                    const model::connector_endpoint& ep) {
                    if (ep.k == model::connector_endpoint::kind::text_box_anchor)
                    {
                        auto it = text_box_id_map.find(ep.text_box_id);
                        if (it != text_box_id_map.end())
                        {
                            sqlite3_bind_int64(c_raw, id_col,
                                               static_cast<sqlite3_int64>(it->second));
                            sqlite3_bind_int  (c_raw, idx_col,
                                               static_cast<int>(ep.anchor_index));
                            return;
                        }
                    }
                    sqlite3_bind_null(c_raw, id_col);
                    sqlite3_bind_null(c_raw, idx_col);
                };
            bind_anchor_ref(8, 9, c.start);
            bind_anchor_ref(10, 11, c.end);

            auto rc_c = sqlite3_step(c_raw);
            if (rc_c != SQLITE_ROW)
                throw std::runtime_error(
                    "Could not insert connector for song '"s + s.name()
                    + "': " + sqlite3_errstr(rc_c));
        }
    }

    tx.commit();
    if (inserted_new)
        lgr()->debug("Inserted new song '{}'", s.name());
}

std::uint64_t database::insert_song_bar(std::uint64_t song_id, std::uint64_t bar_id, unsigned index)
{
    assert(prepared_statements_.count(statement::INSERT_SONG_BAR) == 1);
    auto& ins_sb = prepared_statements_[statement::INSERT_SONG_BAR];
    ins_sb->reset();
    auto raw = ins_sb->ptr();
    sqlite3_bind_int(raw, 1, bar_id);
    sqlite3_bind_int(raw, 2, song_id);
    sqlite3_bind_int(raw, 3, index);
    auto rc = sqlite3_step(raw);
    if (rc != SQLITE_ROW)
        throw std::runtime_error("Could not insert a song bar: "s + sqlite3_errstr(rc));
    lgr()->debug("Inserted relation song({}) with bar({}) position {}", song_id, bar_id, index);
    assert(sqlite3_column_count(raw) == 1);
    return sqlite3_column_int64(raw, 0);
}

void database::maybe_remove_chord(std::uint64_t bar_id, std::uint64_t chord_id)
{
    assert(prepared_statements_.count(statement::SELECT_CHORD_NOT_IN_BAR) == 1);
    auto& sel_c = prepared_statements_[statement::SELECT_CHORD_NOT_IN_BAR];
    sel_c->reset();
    sqlite3_bind_int64(sel_c->ptr(), 1, chord_id);
    sqlite3_bind_int64(sel_c->ptr(), 2, bar_id);
    auto rc = sqlite3_step(sel_c->ptr());
    if (rc == SQLITE_ROW)
        return;
    assert(prepared_statements_.count(statement::REMOVE_CHORD) == 1);
    auto& rem_c = prepared_statements_[statement::REMOVE_CHORD];
    rem_c->reset();
    sqlite3_bind_int64(rem_c->ptr(), 1, chord_id);
    rc = sqlite3_step(rem_c->ptr());
    if (rc != SQLITE_DONE)
        throw std::runtime_error("Could not remove a chord: "s + sqlite3_errstr(rc));
    lgr()->debug("Removed chord with id {}", chord_id);
}

void database::move_to_file(const std::filesystem::path& file_name)
{
    auto abs = std::filesystem::absolute(file_name).lexically_normal();
    database other(abs);
    auto back = sqlite3_backup_init(other.db_, "main", db_, "main");
    if (back == nullptr)
    {
        throw std::runtime_error("Could not initialize moving the database to file '"s +
                                 abs.string() + "': " +
                                 sqlite3_errstr(sqlite3_errcode(other.db_)));
    }
    auto step_rc = sqlite3_backup_step(back, -1);
    auto finish_rc = sqlite3_backup_finish(back);
    auto rc = (step_rc == SQLITE_DONE) ? finish_rc : step_rc;
    if (rc != SQLITE_OK && rc != SQLITE_DONE)
    {
        throw std::runtime_error("Could not move database to file '"s +
                                 file_name.string() + "': " + sqlite3_errstr(rc));
    }

    // other already prepared its own statements against its file-backed db_
    // in its constructor. Swap both members so *this becomes the file-backed
    // database, and other (about to be destroyed) takes the in-memory one.
    std::swap(db_, other.db_);
    std::swap(prepared_statements_, other.prepared_statements_);

    lgr()->info("Moved the in-memory database to the file '{}'", abs.string());
}

void database::remove_playlist(const std::string& pl)
{
    assert(prepared_statements_.count(statement::REMOVE_PLAYLIST) == 1);
    auto& rm_pl = prepared_statements_[statement::REMOVE_PLAYLIST];
    rm_pl->reset();
    sqlite3_bind_text(rm_pl->ptr(), 1, pl.c_str(), pl.length(), SQLITE_STATIC);
    transaction tx(*this);
    auto rc = sqlite3_step(rm_pl->ptr());
    if (rc != SQLITE_DONE)
        throw std::runtime_error("Could not remove playlist '"s + pl + "': " + sqlite3_errstr(rc));
    tx.commit();
    lgr()->debug("Removed playlist '{}'", pl);
}

void database::remove_song(const std::string& s)
{
    assert(prepared_statements_.count(statement::SELECT_SONG_ID) == 1);
    assert(prepared_statements_.count(statement::SELECT_SONG_BARS) == 1);
    assert(prepared_statements_.count(statement::SELECT_CHORDS_BY_BAR) == 1);
    assert(prepared_statements_.count(statement::REMOVE_BAR) == 1);
    assert(prepared_statements_.count(statement::REMOVE_SONG) == 1);

    auto& sel_s = prepared_statements_[statement::SELECT_SONG_ID];
    auto& sel_bids = prepared_statements_[statement::SELECT_SONG_BARS];
    auto& sel_cs = prepared_statements_[statement::SELECT_CHORDS_BY_BAR];
    auto& rem_b  = prepared_statements_[statement::REMOVE_BAR];
    auto& rem_s = prepared_statements_[statement::REMOVE_SONG];

    transaction tx(*this);

    // Look up the song's ID. If it doesn't exist, there's nothing to do.
    sel_s->reset();
    sqlite3_bind_text(sel_s->ptr(), 1, s.c_str(), s.length(), SQLITE_STATIC);
    auto rc = sqlite3_step(sel_s->ptr());
    if (rc == SQLITE_DONE)
        return;  // no such song
    if (rc != SQLITE_ROW)
        throw std::runtime_error("Could not look up song '"s + s + "': " + sqlite3_errstr(rc));
    auto song_id = sqlite3_column_int64(sel_s->ptr(), 0);

    // 1. Collect all bar IDs for this song BEFORE deleting anything,
    //    because deleting the song cascades song_bars rows away.
    std::vector<std::int64_t> bar_ids;
    {
        sel_bids->reset();
        sqlite3_bind_int64(sel_bids->ptr(), 1, song_id);
        auto rc2 = sqlite3_step(sel_bids->ptr());
        while (rc2 == SQLITE_ROW)
        {
            bar_ids.push_back(sqlite3_column_int64(sel_bids->ptr(), 0));
            rc2 = sqlite3_step(sel_bids->ptr());
        }
        if (rc2 != SQLITE_DONE)
            throw std::runtime_error("Could not read song bars: "s + sqlite3_errstr(rc2));
    }

    // 2. For each bar: collect its chord IDs first, call maybe_remove_chord
    //    on each, then delete the bar. The bar_chords rows are cleaned up
    //    by the ON DELETE CASCADE on bar_chords.bar_id.
    for (auto bar_id : bar_ids)
    {
        std::vector<std::int64_t> chord_ids;
        sel_cs->reset();
        sqlite3_bind_int64(sel_cs->ptr(), 1, bar_id);
        auto rc3 = sqlite3_step(sel_cs->ptr());
        while (rc3 == SQLITE_ROW)
        {
            chord_ids.push_back(sqlite3_column_int64(sel_cs->ptr(), 0));
            rc3 = sqlite3_step(sel_cs->ptr());
        }
        if (rc3 != SQLITE_DONE)
            throw std::runtime_error("Could not read bar chords: "s + sqlite3_errstr(rc3));

        // For each chord that was on this bar, remove it if no other
        // bar still references it.
        for (auto chord_id : chord_ids)
            maybe_remove_chord(bar_id, chord_id);

        // Remove the bar itself. Its bar_chords rows cascade away.
        rem_b->reset();
        sqlite3_bind_int64(rem_b->ptr(), 1, bar_id);
        rc3 = sqlite3_step(rem_b->ptr());
        if (rc3 != SQLITE_DONE)
            throw std::runtime_error("Could not remove bar: "s + sqlite3_errstr(rc3));
        lgr()->debug("Removed bar with id {}", bar_id);
    }

    // 4. Finally, remove the song row itself. song_bars cascade is now
    //    a no-op because we already cleared the relevant bars above.
    rem_s->reset();
    sqlite3_bind_int64(rem_s->ptr(), 1, song_id);
    auto rc5 = sqlite3_step(rem_s->ptr());
    if (rc5 != SQLITE_DONE)
        throw std::runtime_error("Could not remove song '"s + s + "': " + sqlite3_errstr(rc5));

    tx.commit();

    lgr()->debug("Removed the song '{}'", s);
}

std::vector<model::bar> database::select_bars(std::uint64_t song_id)
{
    std::vector<model::bar> bars;
    assert(prepared_statements_.count(statement::SELECT_SONG_BARS) == 1);
    assert(prepared_statements_.count(statement::SELECT_BAR) == 1);
    auto& sel_bs = prepared_statements_[statement::SELECT_SONG_BARS];
    sel_bs->reset();
    auto raw = sel_bs->ptr();
    auto& sel_b = prepared_statements_[statement::SELECT_BAR];
    sqlite3_bind_int64(raw, 1, song_id);
    auto rc = sqlite3_step(raw);
    while (rc == SQLITE_ROW)
    {
        sel_b->reset();
        auto bar_id = sqlite3_column_int64(raw, 0);
        sqlite3_bind_int64(sel_b->ptr(), 1, bar_id);
        auto rc2 = sqlite3_step(sel_b->ptr());
        if (rc2 != SQLITE_ROW)
            throw std::runtime_error("Could not look up bar by ID: "s + sqlite3_errstr(rc2));
        model::bar bar;
        bar.is_eol(sqlite3_column_int(sel_b->ptr(), 0));
        if (sqlite3_column_type(sel_b->ptr(), 1) == SQLITE_TEXT)
            bar.section(reinterpret_cast<const char*>(sqlite3_column_text(sel_b->ptr(), 1)));
        else
            assert(sqlite3_column_type(sel_b->ptr(), 1) == SQLITE_NULL);
        if (sqlite3_column_type(sel_b->ptr(), 2) == SQLITE_INTEGER &&
            sqlite3_column_type(sel_b->ptr(), 3) == SQLITE_INTEGER)
        {
            model::time_signature ts;
            ts.kind(static_cast<model::time_signature::beat_type>(sqlite3_column_int(sel_b->ptr(), 2)))
              .count(sqlite3_column_int(sel_b->ptr(), 3));
            bar.time_sig(ts);
        }
        else
        {
            assert(sqlite3_column_type(sel_b->ptr(), 2) == SQLITE_NULL &&
                   sqlite3_column_type(sel_b->ptr(), 3) == SQLITE_NULL);
        }
        bar.repeat(static_cast<model::bar::repeat_status>(sqlite3_column_int(sel_b->ptr(), 4)));
        if (sqlite3_column_type(sel_b->ptr(), 5) == SQLITE_TEXT)
        {
            std::istringstream in(reinterpret_cast<const char*>(sqlite3_column_text(sel_b->ptr(), 5)));
            std::string idx;
            while (std::getline(in, idx, ','))
                bar.add_volta(std::stoi(idx));
        }
        else
        {
            assert(sqlite3_column_type(sel_b->ptr(), 5) == SQLITE_NULL);
        }

        bar.chords(select_chords(bar_id));
        bars.push_back(bar);
        rc = sqlite3_step(raw);
    }
    if (rc != SQLITE_DONE)
        throw std::runtime_error("Could not retrieve bars: "s + sqlite3_errstr(rc));
    return bars;
}

std::vector<model::chord> database::select_chords(std::uint64_t bar_id)
{
    std::vector<model::chord> chords;
    assert(prepared_statements_.count(statement::SELECT_CHORDS_BY_BAR) == 1);
    assert(prepared_statements_.count(statement::SELECT_CHORD_BY_ID) == 1);
    auto& sel_cs = prepared_statements_[statement::SELECT_CHORDS_BY_BAR];
    sel_cs->reset();
    auto raw = sel_cs->ptr();
    sqlite3_bind_int64(raw, 1, bar_id);
    auto& sel_c = prepared_statements_[statement::SELECT_CHORD_BY_ID];
    auto rc = sqlite3_step(raw);
    while (rc == SQLITE_ROW)
    {
        model::chord ch;
        sel_c->reset();
        sqlite3_bind_int64(sel_c->ptr(), 1, sqlite3_column_int64(raw, 0));
        auto rc2 = sqlite3_step(sel_c->ptr());
        if (rc2 != SQLITE_ROW)
            throw std::runtime_error("Could not look up chord by ID: "s + sqlite3_errstr(rc2));
        ch.number(sqlite3_column_int(sel_c->ptr(), 1))
          .mode(static_cast<model::chord::type>(sqlite3_column_int(sel_c->ptr(), 2)));
        if (sqlite3_column_type(sel_c->ptr(), 3) == SQLITE_INTEGER)
            ch.step(static_cast<model::chord::flat_sharp>(sqlite3_column_int(sel_c->ptr(), 3)));
        else
            assert(sqlite3_column_type(sel_c->ptr(), 3) == SQLITE_NULL);
        if (sqlite3_column_type(sel_c->ptr(), 4) == SQLITE_INTEGER)
            ch.bass_note(sqlite3_column_int(sel_c->ptr(), 4));
        else
            assert(sqlite3_column_type(sel_c->ptr(), 4) == SQLITE_NULL);
        if (sqlite3_column_type(sel_c->ptr(), 5) == SQLITE_INTEGER)
            ch.bass_note_step(static_cast<model::chord::flat_sharp>(sqlite3_column_int(sel_c->ptr(), 5)));
        else
            assert(sqlite3_column_type(sel_c->ptr(), 5) == SQLITE_NULL);
        if (sqlite3_column_type(sel_c->ptr(), 6) == SQLITE_TEXT)
            ch.extensions(reinterpret_cast<const char*>(sqlite3_column_text(sel_c->ptr(), 6)));
        else
            assert(sqlite3_column_type(sel_c->ptr(), 6) == SQLITE_NULL);
        ch.is_staccato(sqlite3_column_int(sel_c->ptr(), 7))
          .is_diamond(sqlite3_column_int(sel_c->ptr(), 8));
        if (sqlite3_column_type(sel_c->ptr(), 9) == SQLITE_INTEGER)
            ch.duration(static_cast<model::chord::time>(sqlite3_column_int(sel_c->ptr(), 9)));
        else
            assert(sqlite3_column_type(sel_c->ptr(), 9) == SQLITE_NULL);
        ch.is_tied(sqlite3_column_int(sel_c->ptr(), 10))
          .is_pushed(sqlite3_column_int(sel_c->ptr(), 11));
        chords.push_back(ch);
        rc = sqlite3_step(raw);
    }
    if (rc != SQLITE_DONE)
        throw std::runtime_error("Could not retrieve chords: "s + sqlite3_errstr(rc));
    return chords;
}

model::playlist database::select_playlist(const std::string& name)
{
    model::playlist p(name);
    assert(prepared_statements_.count(statement::SELECT_PLAYLIST_ID) == 1);
    auto& sel_p = prepared_statements_[statement::SELECT_PLAYLIST_ID];
    transaction tx(*this);
    sel_p->reset();
    sqlite3_bind_text(sel_p->ptr(), 1, name.c_str(), name.length(), SQLITE_STATIC);
    auto rc = sqlite3_step(sel_p->ptr());
    if (rc == SQLITE_ROW)
    {
        assert(prepared_statements_.count(statement::SELECT_PLAYLIST_SONGS) == 1);
        auto& sel_ps = prepared_statements_[statement::SELECT_PLAYLIST_SONGS];
        sel_ps->reset();
        auto raw = sel_ps->ptr();
        sqlite3_bind_int64(raw, 1, sqlite3_column_int64(sel_p->ptr(), 0));
        auto rc2 = sqlite3_step(raw);
        while (rc2 == SQLITE_ROW)
        {
            p.add_song(reinterpret_cast<const char*>(sqlite3_column_text(raw, 0)));
            rc2 = sqlite3_step(raw);
        }
        if (rc2 != SQLITE_DONE)
            throw std::runtime_error("Error retrieving playlist songs: "s + sqlite3_errstr(rc));
    }
    else if (rc != SQLITE_DONE)
    {
        throw std::runtime_error("Error retrieving playlist: "s + sqlite3_errstr(rc));
    }
    tx.commit();
    return p;
}

std::vector<std::string> database::select_playlist_names()
{
    std::vector<std::string> names;
    assert(prepared_statements_.count(statement::SELECT_PLAYLIST_NAMES) == 1);
    auto& sel_p = prepared_statements_[statement::SELECT_PLAYLIST_NAMES];
    sel_p->reset();
    auto raw = sel_p->ptr();
    auto rc = sqlite3_step(raw);
    while (rc == SQLITE_ROW)
    {
        names.push_back(reinterpret_cast<const char*>(sqlite3_column_text(raw, 0)));
        rc = sqlite3_step(raw);
    }
    if (rc != SQLITE_DONE)
        throw std::runtime_error("Could not retrieve playlist names: "s + sqlite3_errstr(rc));
    return names;
}

std::vector<std::string> database::select_song_names()
{
    std::vector<std::string> names;
    assert(prepared_statements_.count(statement::SELECT_SONG_NAMES) == 1);
    auto& sel_s = prepared_statements_[statement::SELECT_SONG_NAMES];
    sel_s->reset();
    auto raw = sel_s->ptr();
    auto rc = sqlite3_step(raw);
    while (rc == SQLITE_ROW)
    {
        names.push_back(reinterpret_cast<const char*>(sqlite3_column_text(raw, 0)));
        rc = sqlite3_step(raw);
    }
    if (rc != SQLITE_DONE)
        throw std::runtime_error("Could not retrieve song names: "s + sqlite3_errstr(rc));
    return names;
}

model::song database::select_song(const std::string& name)
{
    model::song found(name);
    assert(prepared_statements_.count(statement::SELECT_SONG) == 1);
    auto& sel_s = prepared_statements_[statement::SELECT_SONG];
    sel_s->reset();
    auto raw = sel_s->ptr();
    transaction tx(*this);
    sqlite3_bind_text(raw, 1, name.c_str(), name.length(), SQLITE_STATIC);
    auto rc = sqlite3_step(raw);
    if (rc == SQLITE_ROW)
    {
        const std::uint64_t song_id = sqlite3_column_int64(raw, 0);
        found.key(reinterpret_cast<const char*>(sqlite3_column_text(raw, 1)));
        found.bars_per_line(sqlite3_column_int(raw, 2));
        found.tempo(std::make_tuple(sqlite3_column_int(raw, 3), static_cast<model::chord::time>(sqlite3_column_int(raw, 4))));
        found.bars(select_bars(song_id));
        model::time_signature ts;
        ts.kind(static_cast<model::time_signature::beat_type>(sqlite3_column_int(raw, 5)))
          .count(sqlite3_column_int(raw, 6));
        found.time_sig(ts);

        // --- Annotations ---
        // Pulled into local vectors first because annotations::load()
        // takes them by value and reseeds next_id_ in a single shot.
        // Handing rows in piecemeal would force us to manage next_id_
        // here, duplicating logic that already lives in the model.
        std::vector<model::text_box>  tbs;
        std::vector<model::connector> conns;
        {
            auto& sel_tb = prepared_statements_[statement::SELECT_SONG_TEXT_BOXES];
            sel_tb->reset();
            auto tb_raw = sel_tb->ptr();
            sqlite3_bind_int64(tb_raw, 1, song_id);
            while (sqlite3_step(tb_raw) == SQLITE_ROW)
            {
                model::text_box tb;
                tb.id   = sqlite3_column_int64(tb_raw, 0);
                tb.rect = QRectF(sqlite3_column_double(tb_raw, 1),
                                 sqlite3_column_double(tb_raw, 2),
                                 sqlite3_column_double(tb_raw, 3),
                                 sqlite3_column_double(tb_raw, 4));
                tb.text = QString::fromUtf8(
                    reinterpret_cast<const char*>(sqlite3_column_text(tb_raw, 5)));
                tbs.push_back(std::move(tb));
            }
        }
        {
            auto& sel_c = prepared_statements_[statement::SELECT_SONG_CONNECTORS];
            sel_c->reset();
            auto c_raw = sel_c->ptr();
            sqlite3_bind_int64(c_raw, 1, song_id);
            while (sqlite3_step(c_raw) == SQLITE_ROW)
            {
                model::connector c;
                c.id = sqlite3_column_int64(c_raw, 0);

                // Free-endpoint fallback positions; for glued
                // endpoints these are also written (as the last-known
                // resolved position), but we use them only when the
                // anchor refs are NULL or the referenced text box
                // doesn't exist in the just-loaded set.
                const QPointF s_xy(sqlite3_column_double(c_raw, 1),
                                   sqlite3_column_double(c_raw, 2));
                const QPointF e_xy(sqlite3_column_double(c_raw, 3),
                                   sqlite3_column_double(c_raw, 4));
                c.arrow_at_start = sqlite3_column_int(c_raw, 5) != 0;
                c.arrow_at_end   = sqlite3_column_int(c_raw, 6) != 0;

                // Reconstruct each endpoint.  Columns 7/8 are start
                // anchor (text_box_id, anchor_index), columns 9/10
                // are end.  NULL in either of the pair means "free."
                auto rebuild_endpoint =
                    [&](int id_col, int idx_col, const QPointF& fallback) {
                        if (sqlite3_column_type(c_raw, id_col)  == SQLITE_NULL ||
                            sqlite3_column_type(c_raw, idx_col) == SQLITE_NULL)
                        {
                            return model::connector_endpoint::make_free(fallback);
                        }
                        const std::uint64_t tb_id = sqlite3_column_int64(c_raw, id_col);
                        const unsigned idx = static_cast<unsigned>(
                            sqlite3_column_int(c_raw, idx_col));
                        return model::connector_endpoint::make_anchor(tb_id, idx);
                    };
                c.start = rebuild_endpoint(7, 8, s_xy);
                c.end   = rebuild_endpoint(9, 10, e_xy);
                conns.push_back(c);
            }
        }
        found.annotations().load(std::move(tbs), std::move(conns));
    }
    else
    {
        throw std::runtime_error("Song '"s + name + "' not found: " + sqlite3_errstr(rc));
    }
    if (sqlite3_step(raw) != SQLITE_DONE)
        throw std::runtime_error("More than one song is named '"s + name + "'");
    tx.commit();
    return found;
}

std::uint64_t database::time_signature_id(const model::time_signature& ts)
{
    assert(prepared_statements_.count(statement::INSERT_TIME_SIGNATURE) == 1);
    assert(prepared_statements_.count(statement::SELECT_TIME_SIGNATURE) == 1);
    auto& sel_ts = prepared_statements_[statement::SELECT_TIME_SIGNATURE];
    auto& ins_ts = prepared_statements_[statement::INSERT_TIME_SIGNATURE];
    sel_ts->reset();
    auto raw = sel_ts->ptr();
    sqlite3_bind_int(raw, 1, static_cast<int>(ts.kind()));
    sqlite3_bind_int(raw, 2, ts.count());
    auto rc = sqlite3_step(raw);
    if (rc == SQLITE_ROW)
        return sqlite3_column_int64(raw, 0);
    ins_ts->reset();
    raw = ins_ts->ptr();
    sqlite3_bind_int(raw, 1, static_cast<int>(ts.kind()));
    sqlite3_bind_int(raw, 2, ts.count());
    rc = sqlite3_step(raw);
    if (rc != SQLITE_ROW)
        throw std::runtime_error("Could not insert a time signature: "s + sqlite3_errstr(rc));
    assert(sqlite3_column_count(raw) == 1);
    return sqlite3_column_int64(raw, 0);
}

}
